from datetime import datetime
from django.shortcuts import render

def index(request):
    return render(request, "Projet/index.html", context={"date": datetime.now()})